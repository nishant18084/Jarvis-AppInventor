# Nexus OS Launcher v1.0

A real Android launcher project for the Realme P3x 5G (RMX3944) or other Android phones.

Features:
- Home screen
- Live clock/date
- App drawer
- App search
- Launch installed apps
- Phone / Messages / Browser / Settings shortcuts
- Nexus Control quick panel
- Dark/Light mode
- Can be selected as the Android Home/Launcher app

Build:
1. Open the folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the APK on the phone.
5. Press Home and select Nexus OS as the default Home app.

Important:
This is a launcher app, not a replacement Android firmware/OS. It does not flash the phone or modify the bootloader.
