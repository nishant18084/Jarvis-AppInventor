package com.nexusos.launcher;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {

    LinearLayout root, homeLayer, drawerLayer, quickPanel;
    GridLayout appGrid;
    EditText search;
    TextView clock, date, drawerTitle;
    boolean drawerOpen = false;
    boolean dark = true;
    PackageManager pm;
    ArrayList<AppItem> apps = new ArrayList<>();

    int bg = Color.rgb(8, 10, 18);
    int card = Color.rgb(25, 29, 42);
    int text = Color.WHITE;
    int sub = Color.rgb(175, 183, 200);
    int accent = Color.rgb(105, 140, 255);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.BLACK);

        pm = getPackageManager();
        buildUI();
        loadApps();
        showHome();
    }

    TextView tv(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(text);
        t.setGravity(Gravity.CENTER);
        t.setFontFeatureSettings("kern");
        return t;
    }

    GradientDrawable rounded(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(r);
        return g;
    }

    void buildUI() {
        FrameLayout frame = new FrameLayout(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 30, 18, 12);
        root.setBackgroundColor(bg);
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));

        // Home
        homeLayer = new LinearLayout(this);
        homeLayer.setOrientation(LinearLayout.VERTICAL);
        root.addView(homeLayer, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setGravity(Gravity.CENTER_HORIZONTAL);
        homeLayer.addView(top, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView logo = tv("NEXUS OS", 13);
        logo.setTextColor(accent);
        logo.setLetterSpacing(.18f);
        top.addView(logo, new LinearLayout.LayoutParams(-1, 48));

        clock = tv("--:--", 56);
        clock.setTypeface(null, android.graphics.Typeface.BOLD);
        top.addView(clock, new LinearLayout.LayoutParams(-1, 75));

        date = tv("Nexus Home", 15);
        date.setTextColor(sub);
        top.addView(date, new LinearLayout.LayoutParams(-1, 35));

        Space spacer = new Space(this);
        top.addView(spacer, new LinearLayout.LayoutParams(1, 20));

        // Main quick tiles
        LinearLayout tiles = new LinearLayout(this);
        tiles.setGravity(Gravity.CENTER);
        String[] names = {"☎", "✉", "◎", "⚙"};
        String[] labels = {"Phone", "Messages", "Browser", "Settings"};
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(8, 8, 8, 8);
            tile.setBackground(rounded(card, 28));
            TextView icon = tv(names[i], 28);
            TextView lab = tv(labels[i], 11);
            lab.setTextColor(sub);
            tile.addView(icon, new LinearLayout.LayoutParams(-1, 42));
            tile.addView(lab, new LinearLayout.LayoutParams(-1, 24));
            tile.setOnClickListener(v -> quickOpen(k));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 88, 1);
            lp.setMargins(5, 0, 5, 0);
            tiles.addView(tile, lp);
        }
        top.addView(tiles, new LinearLayout.LayoutParams(-1, 100));

        // Bottom dock
        LinearLayout dock = new LinearLayout(this);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(8, 8, 8, 8);
        dock.setBackground(rounded(Color.rgb(22, 25, 36), 38));

        TextView drawerBtn = tv("⌃", 28);
        TextView homeBtn = tv("●", 22);
        TextView panelBtn = tv("☰", 24);

        drawerBtn.setOnClickListener(v -> openDrawer());
        homeBtn.setOnClickListener(v -> showHome());
        panelBtn.setOnClickListener(v -> toggleQuickPanel());

        dock.addView(drawerBtn, new LinearLayout.LayoutParams(0, 58, 1));
        dock.addView(homeBtn, new LinearLayout.LayoutParams(0, 58, 1));
        dock.addView(panelBtn, new LinearLayout.LayoutParams(0, 58, 1));
        homeLayer.addView(dock, new LinearLayout.LayoutParams(-1, 74));

        // Drawer
        drawerLayer = new LinearLayout(this);
        drawerLayer.setOrientation(LinearLayout.VERTICAL);
        drawerLayer.setPadding(10, 10, 10, 0);
        drawerLayer.setBackgroundColor(bg);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        drawerTitle = tv("All Apps", 25);
        drawerTitle.setGravity(Gravity.CENTER_VERTICAL);
        drawerTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(drawerTitle, new LinearLayout.LayoutParams(0, 55, 1));

        TextView close = tv("×", 34);
        close.setOnClickListener(v -> showHome());
        header.addView(close, new LinearLayout.LayoutParams(55, 55));
        drawerLayer.addView(header);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search apps");
        search.setHintTextColor(Color.rgb(130, 138, 155));
        search.setTextColor(text);
        search.setTextSize(16);
        search.setPadding(20, 0, 20, 0);
        search.setBackground(rounded(card, 30));
        drawerLayer.addView(search, new LinearLayout.LayoutParams(-1, 52));

        appGrid = new GridLayout(this);
        appGrid.setColumnCount(4);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(appGrid, new ScrollView.LayoutParams(-1, -2));
        drawerLayer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { renderApps(s.toString()); }
            public void afterTextChanged(android.text.Editable e) {}
        });

        // Quick panel overlay
        quickPanel = new LinearLayout(this);
        quickPanel.setOrientation(LinearLayout.VERTICAL);
        quickPanel.setPadding(22, 45, 22, 20);
        quickPanel.setBackground(rounded(Color.rgb(18, 21, 31), 34));
        quickPanel.setVisibility(View.GONE);

        TextView qtitle = tv("Nexus Control", 24);
        qtitle.setGravity(Gravity.LEFT);
        qtitle.setTypeface(null, android.graphics.Typeface.BOLD);
        quickPanel.addView(qtitle, new LinearLayout.LayoutParams(-1, 55));

        LinearLayout qrow = new LinearLayout(this);
        String[] qs = {"Wi‑Fi", "Bluetooth", "Dark Mode", "Settings"};
        for (String q : qs) {
            TextView x = tv(q, 12);
            x.setBackground(rounded(card, 24));
            x.setPadding(4, 4, 4, 4);
            x.setOnClickListener(v -> {
                if (q.equals("Dark Mode")) toggleTheme();
                else if (q.equals("Settings")) openSettings();
                else Toast.makeText(this, q + " control is limited by Android.", Toast.LENGTH_SHORT).show();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 72, 1);
            lp.setMargins(4, 4, 4, 4);
            qrow.addView(x, lp);
        }
        quickPanel.addView(qrow);

        TextView brightness = tv("Brightness  ━━━━━━━━━", 14);
        brightness.setTextColor(sub);
        quickPanel.addView(brightness, new LinearLayout.LayoutParams(-1, 65));

        frame.addView(quickPanel, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        setContentView(frame);
        updateClock();
    }

    void loadApps() {
        apps.clear();
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> list = pm.queryIntentActivities(i, 0);

        for (android.content.pm.ResolveInfo r : list) {
            String label = r.loadLabel(pm).toString();
            String pkg = r.activityInfo.packageName;
            apps.add(new AppItem(label, pkg, r.activityInfo.name, r.loadIcon(pm)));
        }

        Collections.sort(apps, Comparator.comparing(a -> a.label.toLowerCase()));
        renderApps("");
    }

    void renderApps(String filter) {
        if (appGrid == null) return;
        appGrid.removeAllViews();
        String f = filter == null ? "" : filter.toLowerCase();

        for (AppItem a : apps) {
            if (!a.label.toLowerCase().contains(f)) continue;

            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(5, 12, 5, 8);

            ImageView icon = new ImageView(this);
            icon.setImageDrawable(a.icon);
            item.addView(icon, new LinearLayout.LayoutParams(62, 62));

            TextView name = tv(a.label, 11);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            item.addView(name, new LinearLayout.LayoutParams(-1, 28));

            item.setOnClickListener(v -> launch(a));
            appGrid.addView(item, new ViewGroup.LayoutParams(0, 112));
            GridLayout.LayoutParams gl = (GridLayout.LayoutParams)item.getLayoutParams();
            gl.width = 0;
            gl.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            item.setLayoutParams(gl);
        }
    }

    void launch(AppItem a) {
        try {
            Intent in = new Intent();
            in.setClassName(a.pkg, a.cls);
            in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(in);
        } catch (Exception e) {
            Toast.makeText(this, "App could not be opened", Toast.LENGTH_SHORT).show();
        }
    }

    void quickOpen(int k) {
        try {
            Intent i;
            if (k == 0) i = new Intent(Intent.ACTION_DIAL);
            else if (k == 1) i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING);
            else if (k == 2) i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"));
            else { openSettings(); return; }
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "This action is unavailable.", Toast.LENGTH_SHORT).show();
        }
    }

    void openSettings() {
        try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        catch (Exception ignored) {}
    }

    void openDrawer() {
        drawerOpen = true;
        homeLayer.setVisibility(View.GONE);
        drawerLayer.setVisibility(View.VISIBLE);
        ((ViewGroup)root).addView(drawerLayer, 0, new LinearLayout.LayoutParams(-1, 0, 1));
        search.requestFocus();
    }

    void showHome() {
        drawerOpen = false;
        homeLayer.setVisibility(View.VISIBLE);
        if (drawerLayer.getParent() != null)
            ((ViewGroup)drawerLayer.getParent()).removeView(drawerLayer);
        quickPanel.setVisibility(View.GONE);
    }

    void toggleQuickPanel() {
        quickPanel.setVisibility(quickPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    void toggleTheme() {
        dark = !dark;
        bg = dark ? Color.rgb(8,10,18) : Color.rgb(242,244,248);
        card = dark ? Color.rgb(25,29,42) : Color.WHITE;
        text = dark ? Color.WHITE : Color.rgb(25,28,35);
        sub = dark ? Color.rgb(175,183,200) : Color.rgb(90,96,108);
        root.setBackgroundColor(bg);
        if (drawerLayer != null) drawerLayer.setBackgroundColor(bg);
        Toast.makeText(this, dark ? "Dark mode" : "Light mode", Toast.LENGTH_SHORT).show();
    }

    void updateClock() {
        android.os.Handler h = new android.os.Handler();
        Runnable r = new Runnable() {
            public void run() {
                java.text.SimpleDateFormat tf = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault());
                java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("EEE, dd MMM", java.util.Locale.getDefault());
                clock.setText(tf.format(new java.util.Date()));
                date.setText(df.format(new java.util.Date()) + "  •  Nexus OS");
                h.postDelayed(this, 1000);
            }
        };
        h.post(r);
    }

    @Override
    public void onBackPressed() {
        if (quickPanel.getVisibility() == View.VISIBLE) {
            quickPanel.setVisibility(View.GONE);
        } else if (drawerOpen) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }

    static class AppItem {
        String label, pkg, cls;
        android.graphics.drawable.Drawable icon;
        AppItem(String l, String p, String c, android.graphics.drawable.Drawable i) {
            label=l; pkg=p; cls=c; icon=i;
        }
    }
}
